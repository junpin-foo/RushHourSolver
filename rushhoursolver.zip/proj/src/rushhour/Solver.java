package rushhour;

import java.io.*;
import java.util.*;

public class Solver {

    public final static int SIZE = 6;
    public static Board solution;
    public static HashMap<Integer, Board> visited = new HashMap<>();
    public static LinkedList<Board> queue = new LinkedList<Board>();


    public static void solveFromFile(String inputPath, String outputPath) throws Exception, FileNotFoundException {

        char[][] boardTC = new char[6][6];
        Board rushhour;

        try {
            rushhour = new Board(inputPath);
        } catch (Exception e) {
            System.out.println(e.getMessage());
            System.out.println(e.getStackTrace());
            return;
        }

        //start solving
        BFS(rushhour);

        File file2 = new File(outputPath);
        PrintWriter pw = new PrintWriter(file2);

        for(String n : solution.Moves){
            pw.println(n);
        }
        pw.close();

    }

    // do all possible movement up and down ( exception will break when no moves can be donw on a specific side anymore )
    public static void allPossibleMove(Board boardIn) {
        char[][] temp = new char[6][6];
        temp = boardIn.copy();
        Board temp2 = new Board(temp);

        for(char name : boardIn.VehicleName){ //every vehicle name in Board
            Vehicle current = new Vehicle();
            current.search(boardIn,name);

            if (current.orientation == 'V') {

                for (int i = 1; i < 6; i++) {
                    try {
                        Board old = new Board(temp2);
                        old.Moves.addAll(boardIn.Moves); //get all the previous moves to new one

                        current.makeMove(current.name, 1, i, old);
                        old.Moves.add(current.name + "D" + i); //get the latest move

                        if(!visited.containsKey(old.hashCode())){ // check duplicate before adding to queue and visited list
                            queue.add(old);
                            visited.put(old.hashCode(),old);
                        }
                    } catch (Exception e) {
                        break;
                    }
                }
                for (int i = 1; i < 6; i++) {
                    try {
                        Board old = new Board(temp2);
                        old.Moves.addAll(boardIn.Moves);

                        current.makeMove(current.name, 0, i, old);
                        old.Moves.add(current.name + "U" + i);

                        if(!visited.containsKey(old.hashCode())){
                            queue.add(old);
                            visited.put(old.hashCode(),old);
                        }

                    } catch (Exception e) {
                        break;
                    }
                }

            }
            if (current.orientation == 'H') {

                for (int i = 1; i < 6; i++) {
                    try {
                        Board old = new Board(temp2);
                        old.Moves.addAll(boardIn.Moves);

                        current.makeMove(current.name, 2, i, old);
                        old.Moves.add(current.name + "L" + i);

                        if(!visited.containsKey(old.hashCode())){
                            queue.add(old);
                            visited.put(old.hashCode(),old);
                        }

                    } catch (Exception e) {
                        break;
                    }
                }
                for (int i = 1; i < 6; i++) {
                    try {
                        Board old = new Board(temp2);
                        old.Moves.addAll(boardIn.Moves);

                        current.makeMove(current.name, 3, i, old);
                        old.Moves.add(current.name + "R" + i);

                        if(!visited.containsKey(old.hashCode())){
                            queue.add(old);
                            visited.put(old.hashCode(),old);
                        }

                    } catch (Exception e) {
                        break;
                    }
                }
            }
        }
    }

    public static void BFS (Board in){

        queue.add(in);

        while (!queue.isEmpty()) {

            Board current = queue.remove();
            if (current.isSolved()) {
                solution = current; // let out answer be the global variable solution
                return;
            }
            allPossibleMove(current);
        }
    }

    public static void main(String[] args) throws Exception {

        solveFromFile("A00.txt","output.sol");
    }
}


package rushhour;

public class Vehicle{
    public char name;
    public char orientation; // V or H
    public int x1; //coords of any 2 pieces
    public int y1;
    public int x2;
    public int y2;
    public int size;


    public Vehicle(){
    }

    public void search(Board in, char carName){ //get all information of a car

        name = carName;

        int count = 0;

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                if (in.getter(i,j) == carName && count == 0) {
                    x1 = i;
                    y1 = j;
                    count++;
                } else if (in.getter(i,j) == carName && count == 1) {
                    x2 = i;
                    y2 = j;
                }
            }
        }

        int carSize = 0;
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                if (in.getter(i,j) == carName) {
                    carSize++;
                }
            }
        }
        size = carSize;

        if(x1 == x2)
            orientation = 'H';
        else
            orientation = 'V';
    }

    public char getOrientation(){
        return orientation;
    }

    public void makeMove(char carName, int dir, int length, Board in) throws Exception{

        if (dir > 3 || dir < 0)  // 0 up, 1 down, 2 left, 3 right
            throw new Exception("No such direction");

        int counter;

        if (orientation == 'V') { // vertical
            if (dir != 0 && dir != 1)
                throw new Exception("Vertical cars can only move up/down");


            switch (dir) {
                case 0: //move up
                    counter = 0;
                    for (int i = 0; i < 6; i++) {
                        for (int j = 0; j < 6; j++) {
                            if (in.getter(i,j) == carName) {
                                if (notOverlapped(dir, i, j, in, length, carName)&& counter != size) {
                                    in.setter(i,j, '.');
                                    in.setter(i - length,j,carName);
                                    counter++;
                                }
                                else if (counter == 0) {
                                    throw new Exception("Overlapped while moving up");
                                }
                            }
                        }
                    }
                    break;
                case 1: //move down
                    counter = 0;
                    for (int i = 5; i >= 0; i--) {
                        for (int j = 5; j >= 0; j--) {
                            if (in.getter(i,j) == carName) {
                                if (notOverlapped(dir, i, j, in, length, carName)&& counter != size) {
                                    char temp = in.getter(i,j);
                                    in.setter(i,j, '.');
                                    in.setter(i + length,j,temp);
                                    counter++;
                                }
                                else if (counter == 0) {
                                    throw new Exception("Overlapped while moving down");
                                }
                            }
                        }
                    }
                    break;
            }
        }
        if (orientation == 'H') { //horizontal
            if (dir != 2 && dir != 3)
                throw new Exception("Horizontal cars can only move left/right");


            switch (dir) {
                case 2: //move left
                    counter = 0;
                    for (int i = 0; i < 6; i++) {
                        for (int j = 0; j < 6; j++) {
                            if (in.getter(i,j) == carName) {
                                if (notOverlapped(dir, i, j, in, length, carName)&& counter != size) {
                                    in.setter(i,j, '.');
                                    in.setter(i,j - length,carName);

                                    counter++;
                                }
                                else if (counter == 0) {
                                    throw new Exception("Overlapped while moving to the left");
                                }
                            }
                        }
                    }
                    break;
                case 3: //move right
                    counter = 0;
                    for (int i = 5; i >= 0; i--) {
                        for (int j = 5; j >= 0; j--) {
                            if (in.getter(i,j) == carName) {
                                if (notOverlapped(dir, i, j, in, length, carName)&& counter != size) {
                                    char temp = in.getter(i,j);
                                    in.setter(i,j, '.');
                                    in.setter(i,j + length,temp);

                                    counter++;
                                }
                                else if (counter == 0) {
                                    throw new Exception("Overlapped while moving to the right");
                                }
                            }
                        }
                    }
                    break;
            }
        }
    }

    public boolean notOverlapped(int dir, int I, int J, Board array, int length, char carName) { // I,J is current position

        if (dir == 0) {
            if (I - length < 0) // move up
                return false;
            for (int i = I; i >= I - length; i--) {
                if (array.getter(i,J) == '.' || array.getter(i,J) == carName)
                    continue;
                else{
                    return false;
                }
            }
            return true;
        } else if (dir == 1) {
            if (length + I > 5) // move down
                return false;
            for (int i = I; i <= length + I; i++) {
                if (array.getter(i,J) == '.' || array.getter(i,J) == carName)
                    continue;
                else
                    return false;
            }
            return true;
        } else if (dir == 2) {
            if (J - length < 0) // move left
                return false;
            for (int j = J; j >= J - length; j--) {
                if (array.getter(I,j) == '.' || array.getter(I,j) == carName)
                    continue;
                else
                    return false;
            }
            return true;
        } else if (dir == 3) {
            if (length + J > 5) // move right
                return false;
            for (int j = J; j <= length + J; j++) {
                if (array.getter(I,j) == '.' || array.getter(I,j) == carName)
                    continue;
                else
                    return false;
            }
            return true;
        } else {
            return false;
        }
    }

}

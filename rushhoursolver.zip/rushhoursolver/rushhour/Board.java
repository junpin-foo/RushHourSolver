package rushhour;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Board {
    public char[][] board = new char[6][6];
    public ArrayList<Character> VehicleName = new ArrayList<Character>();
    public int totalVehicle;
    public ArrayList<String> Moves = new ArrayList<String>();

    public Board(String fileName) throws FileNotFoundException, Exception {
        File boardFile = new File(fileName);
        if(!boardFile.exists())
            throw new FileNotFoundException();

        Scanner read = new Scanner(boardFile);

        try{
            for(int i = 0; i < 6; i++){
                String s = read.nextLine();
                if(s.length() == 6){
                    board[i] = s.toCharArray();
                }
                else
                    throw new Exception("Wrong board size at line " + i); // wrong length
            }
            if(read.hasNext())
                throw new Exception("Wrong board height.");
        } finally {
            read.close();
            allVehicle();
        }
    }

    public Board(){
    }

    public Board(Board in, String move){
        board = in.board;
        Moves = in.Moves;
        Moves.add(move);
    }

    public Board(Board in){
        char[][] temp = in.copy();
        board = temp;
        allVehicle();
    }

    public Board(char[][] in){
        board = in;
        allVehicle();
    }

    public char[][] copy () {
        char[][] temp = new char[6][6];
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                temp[i][j] = this.board[i][j];
            }
        }
        return temp;
    }

    public char getter(int a, int b){
        return board[a][b];
    }

    public void setter(int a, int b, char C){
        board[a][b] = C;
    }

    public ArrayList<String> getMoves(){
        return Moves;
    }

    public void allVehicle(){
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++){
                if (board[i][j] != '.' && !VehicleName.contains(board[i][j])){
                    VehicleName.add(board[i][j]);
                    totalVehicle++;
                }
            }
        }
    }
    public boolean isSolved() {
        if(board[2][5] == 'X'){
            return true;
        }
        return false;
    }

    @Override
    public boolean equals(Object obj) {

        if (this == obj)
            return true;

        if (obj == null)
            return false;

        if (getClass() != obj.getClass())
            return false;

        Board other = (Board) obj;
        if (hashCode() != other.hashCode())
            return false;

        if (!Arrays.deepEquals(board, other.board))
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = 31 * Arrays.deepHashCode(board);
        return result;
    }
}
